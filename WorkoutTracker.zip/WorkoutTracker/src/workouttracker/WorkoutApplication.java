package workouttracker;

// Abstract class Workout to hold workout details
abstract class Workout {
    // Fields for exercises, duration in minutes, and intensity level
    private String exercises;
    private int duration;
    private int intensityLevel;

    // Constructor to initialize the fields
    public Workout(String exercises, int duration, int intensityLevel) {
        this.exercises = exercises;
        this.duration = duration;
        this.intensityLevel = intensityLevel;
    }

    // Getter method for exercises
    public String getExercises() {
        return exercises;
    }

    // Getter method for duration
    public int getDuration() {
        return duration;
    }

    // Getter method for intensity level
    public int getIntensityLevel() {
        return intensityLevel;
    }
}

// Interface IWorkout with a method to print workout details
public interface IWorkout {
    void printWorkout();
}

// Class ProcessWorkout inherits from Workout and implements IWorkout
class ProcessWorkout extends Workout implements IWorkout {

    // Constructor for ProcessWorkout calling superclass constructor
    public ProcessWorkout(String exercises, int duration, int intensityLevel) {
        super(exercises, duration, intensityLevel);
    }

    // Implementation of printWorkout method to display the workout details
    @Override
    public void printWorkout() {
        System.out.println("Workout Details:");
        System.out.println("Exercises: " + getExercises());
        System.out.println("Duration: " + getDuration() + " minutes");
        System.out.println("Intensity Level: " + getIntensityLevel());
    }
}

// Main class WorkoutApplication with the main method to run the application
public class WorkoutApplication {
    public static void main(String[] args) {
        // Sample workout creation
        ProcessWorkout workout = new ProcessWorkout("Push-ups, Squats, Burpees", 30, 4);

        workout.printWorkout();
    }
}

//Title: Fitness Tracker App Using Java Swing
//Author: Code With Curious
//Date: 06 September 2024
//Version: 1
//Available: https://codewithcurious.com/java/fitness-tracker-app-using-java/

